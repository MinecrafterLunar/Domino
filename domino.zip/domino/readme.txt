﻿原Readme
==================================================================

  MIDI 音乐编辑软件“Domino”
  Copyright (C) 2007-2013 Takabo Soft (http://takabosoft.com/)


感谢你下载了 Domino
使用手册在此↓，请阅读手册获取详细信息
Manual/index.htm

（在程序中按 F1 也可以打开使用手册）
==================================================================
汉化者补充：
至于那本使用手册，我认为文本量实在有些大，所以并没有汉化，你可以
搜索一些教程，或者自己摸索摸索，软件使用上并不难，使用过同类软件的
人一般会很容易上手。
音源定义文件只汉化了 GMLevel1 与 GSm ，需要其他文件可以自己用
notepad++ 将原来的 shift-jis 编码在中文版系统上转换为 ANSI(或GBK)
编码即可正常使用

如果 Control Change 的行为出现乱码，请在设置里面打开“Control 
Change 行为树”的“使用等宽字体”


金毛科技工作室 金毛(djy0212)汉化(｀・ω・´)
另外感谢X_panda
如果汉化哪里有问题和缺漏，或者与术语有不符，请联系汉化者金毛。
邮箱是djy0212(at)foxmail.com


如果 Takabosoft 认为汉化版本侵权，请联系我，我会随时把该软件从
发布处撤下
*If Takabosoft thinks my Chinese version of Domino is against the 
copyright, please contact me and I will remove the published files.
My email is djy0212(at)foxmail.com